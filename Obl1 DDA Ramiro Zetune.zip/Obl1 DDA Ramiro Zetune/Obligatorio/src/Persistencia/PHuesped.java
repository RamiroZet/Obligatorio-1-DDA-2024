package Persistencia;

import Dominio.Huesped;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PHuesped {
    private static Conexion conexion = new Conexion();

    public static boolean agregarHuesped(Huesped huesped) {
        String sql = "INSERT INTO huesped(idhuesped, nombre, apaterno, amaterno, tipo_documento, num_documento, fecha_nac, telefono, pais) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(
                huesped.getIdHuesped(), huesped.getNombre(), huesped.getApaterno(), huesped.getAmaterno(),
                huesped.getTipo_Documento(), huesped.getNum_Documento(), huesped.getFecha_Nac(),
                huesped.getTelefono(), huesped.getPais()
        ));
        return conexion.consulta(sql, parametros);
    }

    public static boolean eliminarHuesped(int idHuesped) {
        String sql = "DELETE FROM huesped WHERE idhuesped=?";
        return conexion.consulta(sql, new ArrayList<>(Arrays.asList(idHuesped)));
    }

    public static boolean modificarHuesped(Huesped huesped) {
        String sql = "UPDATE huesped SET nombre=?, apaterno=?, amaterno=?, tipo_documento=?, num_documento=?, fecha_nac=?, telefono=?, pais=? WHERE idhuesped=?";
        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(
                huesped.getNombre(), huesped.getApaterno(), huesped.getAmaterno(), huesped.getTipo_Documento(),
                huesped.getNum_Documento(), huesped.getFecha_Nac(), huesped.getTelefono(),
                huesped.getPais(), huesped.getIdHuesped()
        ));
        return conexion.consulta(sql, parametros);
    }

    public static Huesped conseguirHuesped(int idHuesped) {
        String sql = "SELECT * FROM huesped WHERE idhuesped=?";
        List<List<Object>> resultado = conexion.seleccion(sql, new ArrayList<>(Arrays.asList(idHuesped)));
        if (resultado.isEmpty()) return null;
        List<Object> registro = resultado.get(0);
        return new Huesped(
                (int) registro.get(0), String.valueOf(registro.get(1)), String.valueOf(registro.get(2)),
                String.valueOf(registro.get(3)), String.valueOf(registro.get(4)), String.valueOf(registro.get(5)),
                (LocalDate) registro.get(6), String.valueOf(registro.get(7)), String.valueOf(registro.get(8))
        );
    }

    public static ArrayList<Huesped> listarHuespedes() {
        String sql = "SELECT * FROM huesped";
        List<List<Object>> registros = conexion.seleccion(sql, null);
        ArrayList<Huesped> huespedes = new ArrayList<>();
        for (List<Object> registro : registros) {
            huespedes.add(new Huesped(
                    (int) registro.get(0), String.valueOf(registro.get(1)), String.valueOf(registro.get(2)),
                    String.valueOf(registro.get(3)), String.valueOf(registro.get(4)), String.valueOf(registro.get(5)),
                    (LocalDate) registro.get(6), String.valueOf(registro.get(7)), String.valueOf(registro.get(8))
            ));
        }
        return huespedes;
    }
}
