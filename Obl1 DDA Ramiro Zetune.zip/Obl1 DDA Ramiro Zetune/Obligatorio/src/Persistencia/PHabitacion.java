package Persistencia;

import Dominio.Habitacion;
import Dominio.Hotel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PHabitacion {
    private static Conexion conexion = new Conexion();

    // Agregar una habitación
    public static boolean agregarHabitacion(Habitacion habitacion) {
        String sql = "INSERT INTO Habitacion(idHabitacion, idHotel, capacidadCamas, camaMatrimonial, aireAcondicionado, balcon, vista, amenities, ocupada) " +
                "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(
                habitacion.getIdHabitacion(), habitacion.getHotel().getIdHotel(), habitacion.getCapacidadCamas(),
                habitacion.isCamaMatrimonial(), habitacion.isAireAcondicionado(), habitacion.isBalcon(),
                habitacion.isVista(), habitacion.isAmenities(), habitacion.isOcupada()
        ));
        return conexion.consulta(sql, parametros);
    }

    // Eliminar una habitación por su ID
    public static boolean eliminarHabitacion(int idHabitacion) {
        String sql = "DELETE FROM Habitacion WHERE idHabitacion=?";
        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(idHabitacion));
        return conexion.consulta(sql, parametros);
    }

    // Modificar los datos de una habitación
    public static boolean modificarHabitacion(Habitacion habitacion) {
        String sql = "UPDATE Habitacion SET idHotel=?, capacidadCamas=?, camaMatrimonial=?, aireAcondicionado=?, balcon=?, vista=?, amenities=?, ocupada=? " +
                "WHERE idHabitacion=?";
        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(
                habitacion.getHotel().getIdHotel(), habitacion.getCapacidadCamas(), habitacion.isCamaMatrimonial(),
                habitacion.isAireAcondicionado(), habitacion.isBalcon(), habitacion.isVista(),
                habitacion.isAmenities(), habitacion.isOcupada(), habitacion.getIdHabitacion()
        ));
        return conexion.consulta(sql, parametros);
    }

    // Conseguir una habitación específica por su ID
    public static Habitacion conseguirHabitacion(int idHabitacion) {
        String sql = "SELECT * FROM Habitacion WHERE idHabitacion=?";
        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(idHabitacion));

        List<List<Object>> resultado = conexion.seleccion(sql, parametros);
        if (resultado.isEmpty()) return null;

        List<Object> registro = resultado.get(0);
        Hotel hotel = new Hotel((int) registro.get(1), "", "", "", 0, "", "", null);
        return new Habitacion(
                (int) registro.get(0), hotel, (int) registro.get(2),
                (boolean) registro.get(3), (boolean) registro.get(4), (boolean) registro.get(5),
                (boolean) registro.get(6), (boolean) registro.get(7), (boolean) registro.get(8)
        );
    }

    // Listar todas las habitaciones
    public static ArrayList<Habitacion> listarHabitaciones() {
        String sql = "SELECT * FROM Habitacion";
        List<List<Object>> registros = conexion.seleccion(sql, null);
        ArrayList<Habitacion> habitaciones = new ArrayList<>();

        for (List<Object> registro : registros) {
            Hotel hotel = new Hotel((int) registro.get(1), "", "", "", 0, "", "", null);
            Habitacion habitacion = new Habitacion(
                    (int) registro.get(0), hotel, (int) registro.get(2),
                    (boolean) registro.get(3), (boolean) registro.get(4), (boolean) registro.get(5),
                    (boolean) registro.get(6), (boolean) registro.get(7), (boolean) registro.get(8)
            );
            habitaciones.add(habitacion);
        }
        return habitaciones;
    }

    // Listar habitaciones con reserva
    public static List<Habitacion> listarHabitacionesConReserva() {
        List<Habitacion> habitaciones = new ArrayList<>();
        String sql = "SELECT h.* FROM Habitacion h JOIN Reserva r ON h.idHabitacion = r.idHabitacion";

        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Hotel hotel = new Hotel(rs.getInt("idHotel"), "", "", "", 0, "", "", null);
                Habitacion habitacion = new Habitacion(
                        rs.getInt("idHabitacion"),
                        hotel,
                        rs.getInt("capacidadCamas"),
                        rs.getBoolean("camaMatrimonial"),
                        rs.getBoolean("aireAcondicionado"),
                        rs.getBoolean("balcon"),
                        rs.getBoolean("vista"),
                        rs.getBoolean("amenities"),
                        rs.getBoolean("ocupada")
                );
                habitaciones.add(habitacion);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar habitaciones con reserva: " + e.getMessage());
        }
        return habitaciones;
    }

    // Listar habitaciones sin reserva
    public static List<Habitacion> listarHabitacionesSinReserva() {
        List<Habitacion> habitaciones = new ArrayList<>();
        String sql = "SELECT h.* FROM Habitacion h LEFT JOIN Reserva r ON h.idHabitacion = r.idHabitacion WHERE r.idReserva IS NULL";

        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Hotel hotel = new Hotel(rs.getInt("idHotel"), "", "", "", 0, "", "", null);
                Habitacion habitacion = new Habitacion(
                        rs.getInt("idHabitacion"),
                        hotel,
                        rs.getInt("capacidadCamas"),
                        rs.getBoolean("camaMatrimonial"),
                        rs.getBoolean("aireAcondicionado"),
                        rs.getBoolean("balcon"),
                        rs.getBoolean("vista"),
                        rs.getBoolean("amenities"),
                        rs.getBoolean("ocupada")
                );
                habitaciones.add(habitacion);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar habitaciones sin reserva: " + e.getMessage());
        }
        return habitaciones;
    }
}
