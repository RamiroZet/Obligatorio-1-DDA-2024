package Controladora;

import Dominio.Huesped;
import Persistencia.PHuesped;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class ControladoraHuesped {
    private static Scanner escaner = new Scanner(System.in);

    public void agregarHuesped() {
        System.out.println("Agregar huésped");

        int idHuesped;
        do {
            System.out.print("Ingrese ID del huésped: ");
            try {
                idHuesped = Integer.parseInt(escaner.nextLine());
            } catch (Exception e) {
                idHuesped = 0;
                System.out.println("ID inválido. Intente nuevamente.");
            }
        } while (idHuesped == 0);

        System.out.print("Ingrese el nombre del huésped: ");
        String nombre = escaner.nextLine();

        System.out.print("Ingrese el apellido paterno: ");
        String apaterno = escaner.nextLine();

        System.out.print("Ingrese el apellido materno: ");
        String amaterno = escaner.nextLine();

        System.out.print("Ingrese el tipo de documento: ");
        String tipoDocumento = escaner.nextLine();

        System.out.print("Ingrese el número de documento: ");
        String numDocumento = escaner.nextLine();

        LocalDate fechaNac = null;
        while (fechaNac == null) {
            try {
                System.out.print("Ingrese la fecha de nacimiento (YYYY-MM-DD): ");
                fechaNac = LocalDate.parse(escaner.nextLine());
            } catch (Exception e) {
                System.out.println("Fecha inválida. Intente nuevamente.");
            }
        }

        System.out.print("Ingrese el teléfono: ");
        String telefono = escaner.nextLine();

        System.out.print("Ingrese el país: ");
        String pais = escaner.nextLine();

        Huesped huesped = new Huesped(idHuesped, nombre, apaterno, amaterno, tipoDocumento, numDocumento, fechaNac, telefono, pais);

        if (PHuesped.agregarHuesped(huesped)) {
            System.out.println("Huésped agregado con éxito.");
        } else {
            System.out.println("Hubo un error al agregar el huésped.");
        }
    }

    public void eliminarHuesped() {
        System.out.print("Ingrese ID del huésped a eliminar: ");
        int idHuesped = Integer.parseInt(escaner.nextLine());

        if (PHuesped.eliminarHuesped(idHuesped)) {
            System.out.println("Huésped eliminado con éxito.");
        } else {
            System.out.println("No se pudo eliminar el huésped.");
        }
    }

    public void modificarHuesped() {
        System.out.print("Ingrese ID del huésped a modificar: ");
        int idHuesped = Integer.parseInt(escaner.nextLine());

        Huesped huesped = PHuesped.conseguirHuesped(idHuesped);
        if (huesped == null) {
            System.out.println("Huésped no encontrado.");
            return;
        }

        System.out.print("Ingrese el nombre del huésped (" + huesped.getNombre() + "): ");
        String nombre = escaner.nextLine();
        if (!nombre.isEmpty()) huesped.setNombre(nombre);

        System.out.print("Ingrese el apellido paterno (" + huesped.getApaterno() + "): ");
        String apaterno = escaner.nextLine();
        if (!apaterno.isEmpty()) huesped.setApaterno(apaterno);

        System.out.print("Ingrese el apellido materno (" + huesped.getAmaterno() + "): ");
        String amaterno = escaner.nextLine();
        if (!amaterno.isEmpty()) huesped.setAmaterno(amaterno);

        System.out.print("Ingrese el tipo de documento (" + huesped.getTipo_Documento() + "): ");
        String tipoDocumento = escaner.nextLine();
        if (!tipoDocumento.isEmpty()) huesped.setTipo_Documento(tipoDocumento);

        System.out.print("Ingrese el número de documento (" + huesped.getNum_Documento() + "): ");
        String numDocumento = escaner.nextLine();
        if (!numDocumento.isEmpty()) huesped.setNum_Documento(numDocumento);

        LocalDate fechaNac = null;
        while (fechaNac == null) {
            try {
                System.out.print("Ingrese la fecha de nacimiento (" + huesped.getFecha_Nac() + ") (YYYY-MM-DD): ");
                fechaNac = LocalDate.parse(escaner.nextLine());
                if (fechaNac != null) huesped.setFecha_Nac(fechaNac);
            } catch (Exception e) {
                System.out.println("Fecha inválida. Intente nuevamente.");
            }
        }

        System.out.print("Ingrese el teléfono (" + huesped.getTelefono() + "): ");
        String telefono = escaner.nextLine();
        if (!telefono.isEmpty()) huesped.setTelefono(telefono);

        System.out.print("Ingrese el país (" + huesped.getPais() + "): ");
        String pais = escaner.nextLine();
        if (!pais.isEmpty()) huesped.setPais(pais);

        if (PHuesped.modificarHuesped(huesped)) {
            System.out.println("Huésped modificado con éxito.");
        } else {
            System.out.println("Hubo un error al modificar el huésped.");
        }
    }

    public void conseguirHuesped() {
        System.out.print("Ingrese ID del huésped: ");
        int idHuesped = Integer.parseInt(escaner.nextLine());

        Huesped huesped = PHuesped.conseguirHuesped(idHuesped);
        if (huesped != null) {
            System.out.println(huesped);
        } else {
            System.out.println("Huésped no encontrado.");
        }
    }

    public void listarHuespedes() {
        System.out.println("Listado de huéspedes:");
        for (Huesped huesped : PHuesped.listarHuespedes()) {
            System.out.println(huesped);
        }
    }
}
