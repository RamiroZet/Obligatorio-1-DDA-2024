package Controladora;

import Dominio.Habitacion;
import Dominio.Hotel;
import Persistencia.PHabitacion;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ControladoraHabitacion {
    private static Scanner escaner = new Scanner(System.in);

    public void agregarHabitacion() {
        System.out.println("Agregar habitación");

        int idHabitacion;
        do {
            System.out.print("Ingrese ID de la habitación: ");
            try {
                idHabitacion = Integer.parseInt(escaner.nextLine());
            } catch (Exception e) {
                idHabitacion = 0;
                System.out.println("ID inválido. Intente nuevamente.");
            }
        } while (idHabitacion == 0);

        System.out.print("Ingrese ID del hotel: ");
        int idHotel = Integer.parseInt(escaner.nextLine());

        System.out.print("Ingrese la capacidad de camas: ");
        int capacidadCamas = Integer.parseInt(escaner.nextLine());

        System.out.print("¿Tiene cama matrimonial? (true/false): ");
        boolean camaMatrimonial = Boolean.parseBoolean(escaner.nextLine());

        System.out.print("¿Tiene aire acondicionado? (true/false): ");
        boolean aireAcondicionado = Boolean.parseBoolean(escaner.nextLine());

        System.out.print("¿Tiene balcón? (true/false): ");
        boolean balcon = Boolean.parseBoolean(escaner.nextLine());

        System.out.print("¿Tiene vista? (true/false): ");
        boolean vista = Boolean.parseBoolean(escaner.nextLine());

        System.out.print("¿Tiene amenities? (true/false): ");
        boolean amenities = Boolean.parseBoolean(escaner.nextLine());

        System.out.print("¿Está ocupada? (true/false): ");
        boolean ocupada = Boolean.parseBoolean(escaner.nextLine());

        Habitacion habitacion = new Habitacion(idHabitacion, new Hotel(idHotel, "", "", "", 0, "", "", null),
                capacidadCamas, camaMatrimonial, aireAcondicionado, balcon, vista, amenities, ocupada);

        if (PHabitacion.agregarHabitacion(habitacion)) {
            System.out.println("Habitación agregada con éxito.");
        } else {
            System.out.println("Hubo un error al agregar la habitación.");
        }
    }

    public void eliminarHabitacion() {
        System.out.print("Ingrese ID de la habitación a eliminar: ");
        int idHabitacion = Integer.parseInt(escaner.nextLine());

        if (PHabitacion.eliminarHabitacion(idHabitacion)) {
            System.out.println("Habitación eliminada con éxito.");
        } else {
            System.out.println("No se pudo eliminar la habitación.");
        }
    }

    public void modificarHabitacion() {
        System.out.print("Ingrese ID de la habitación a modificar: ");
        int idHabitacion = Integer.parseInt(escaner.nextLine());

        Habitacion habitacion = PHabitacion.conseguirHabitacion(idHabitacion);
        if (habitacion == null) {
            System.out.println("Habitación no encontrada.");
            return;
        }

        System.out.print("Ingrese ID del hotel (" + habitacion.getHotel().getIdHotel() + "): ");
        String idHotelStr = escaner.nextLine();
        if (!idHotelStr.isEmpty()) habitacion.setHotel(new Hotel(Integer.parseInt(idHotelStr), "", "", "", 0, "", "", null));

        System.out.print("Ingrese la capacidad de camas (" + habitacion.getCapacidadCamas() + "): ");
        String capacidadCamasStr = escaner.nextLine();
        if (!capacidadCamasStr.isEmpty()) habitacion.setCapacidadCamas(Integer.parseInt(capacidadCamasStr));

        System.out.print("¿Tiene cama matrimonial? (" + habitacion.isCamaMatrimonial() + "): ");
        String camaMatrimonialStr = escaner.nextLine();
        if (!camaMatrimonialStr.isEmpty()) habitacion.setCamaMatrimonial(Boolean.parseBoolean(camaMatrimonialStr));

        System.out.print("¿Tiene aire acondicionado? (" + habitacion.isAireAcondicionado() + "): ");
        String aireAcondicionadoStr = escaner.nextLine();
        if (!aireAcondicionadoStr.isEmpty()) habitacion.setAireAcondicionado(Boolean.parseBoolean(aireAcondicionadoStr));

        System.out.print("¿Tiene balcón? (" + habitacion.isBalcon() + "): ");
        String balconStr = escaner.nextLine();
        if (!balconStr.isEmpty()) habitacion.setBalcon(Boolean.parseBoolean(balconStr));

        System.out.print("¿Tiene vista? (" + habitacion.isVista() + "): ");
        String vistaStr = escaner.nextLine();
        if (!vistaStr.isEmpty()) habitacion.setVista(Boolean.parseBoolean(vistaStr));

        System.out.print("¿Tiene amenities? (" + habitacion.isAmenities() + "): ");
        String amenitiesStr = escaner.nextLine();
        if (!amenitiesStr.isEmpty()) habitacion.setAmenities(Boolean.parseBoolean(amenitiesStr));

        System.out.print("¿Está ocupada? (" + habitacion.isOcupada() + "): ");
        String ocupadaStr = escaner.nextLine();
        if (!ocupadaStr.isEmpty()) habitacion.setOcupada(Boolean.parseBoolean(ocupadaStr));

        if (PHabitacion.modificarHabitacion(habitacion)) {
            System.out.println("Habitación modificada con éxito.");
        } else {
            System.out.println("Hubo un error al modificar la habitación.");
        }
    }

    public void conseguirHabitacion() {
        System.out.print("Ingrese ID de la habitación: ");
        int idHabitacion = Integer.parseInt(escaner.nextLine());

        Habitacion habitacion = PHabitacion.conseguirHabitacion(idHabitacion);
        if (habitacion != null) {
            System.out.println(habitacion);
        } else {
            System.out.println("Habitación no encontrada.");
        }
    }

    public void listarHabitaciones() {
        System.out.println("Listado de habitaciones:");
        for (Habitacion habitacion : PHabitacion.listarHabitaciones()) {
            System.out.println(habitacion);
        }
    }
    //Consulta n 3
    public void listarHabitacionesConYSinReserva() {
        List<Habitacion> habitacionesConReserva = PHabitacion.listarHabitacionesConReserva();
        List<Habitacion> habitacionesSinReserva = PHabitacion.listarHabitacionesSinReserva();

        System.out.println("Habitaciones con reserva:");
        for (Habitacion habitacion : habitacionesConReserva) {
            System.out.println(habitacion);
        }

        System.out.println("\nHabitaciones sin reserva:");
        for (Habitacion habitacion : habitacionesSinReserva) {
            System.out.println(habitacion);
        }
    }

}

