package Controladora;

import Dominio.Hotel;
import Dominio.Huesped;
import Dominio.Habitacion;
import Dominio.Reserva;
import Persistencia.PHabitacion;
import Persistencia.PReserva;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class ControladoraReserva {
    private static Scanner escaner = new Scanner(System.in);

    public void agregarReserva() {
        System.out.println("Agregar reserva");

        int idReserva;
        do {
            System.out.print("Ingrese ID de la reserva: ");
            try {
                idReserva = Integer.parseInt(escaner.nextLine());
            } catch (Exception e) {
                idReserva = 0;
                System.out.println("ID inválido. Intente nuevamente.");
            }
        } while (idReserva == 0);

        System.out.print("Ingrese ID del huésped: ");
        int idHuesped = Integer.parseInt(escaner.nextLine());

        System.out.print("Ingrese ID del hotel: ");
        int idHotel = Integer.parseInt(escaner.nextLine());

        System.out.print("Ingrese ID de la habitación: ");
        int idHabitacion = Integer.parseInt(escaner.nextLine());

        System.out.print("Ingrese la cantidad de personas: ");
        int cantidadPersonas = Integer.parseInt(escaner.nextLine());

        System.out.print("Ingrese la fecha de inicio (YYYY-MM-DD): ");
        LocalDate fechaInicio = LocalDate.parse(escaner.nextLine());

        System.out.print("Ingrese la fecha de fin (YYYY-MM-DD): ");
        LocalDate fechaFin = LocalDate.parse(escaner.nextLine());

        System.out.print("¿Está abonado completamente? (true/false): ");
        boolean abonadoCompletamente = Boolean.parseBoolean(escaner.nextLine());

        LocalDate fechaReserva = LocalDate.now(); // Se asume la fecha actual como fecha de reserva

        System.out.print("Ingrese observaciones (si las hay): ");
        String observacion = escaner.nextLine();

        Reserva reserva = new Reserva(idReserva,
                new Huesped(idHuesped, "", "", "", "", "", LocalDate.now(), "", ""),
                new Hotel(idHotel, "", "", "", 0, "", "", null),
                new Habitacion(idHabitacion, null, 0, false, false, false, false, false, false),
                cantidadPersonas, fechaInicio, fechaFin, abonadoCompletamente, fechaReserva, observacion);

        if (PReserva.agregarReserva(reserva)) {
            System.out.println("Reserva agregada con éxito.");
        } else {
            System.out.println("Hubo un error al agregar la reserva.");
        }
    }

    public void eliminarReserva() {
        System.out.print("Ingrese ID de la reserva a eliminar: ");
        int idReserva = Integer.parseInt(escaner.nextLine());

        if (PReserva.eliminarReserva(idReserva)) {
            System.out.println("Reserva eliminada con éxito.");
        } else {
            System.out.println("No se pudo eliminar la reserva. Verifique el ID.");
        }
    }

    public void modificarReserva() {
        System.out.print("Ingrese ID de la reserva a modificar: ");
        int idReserva = Integer.parseInt(escaner.nextLine());

        Reserva reservaExistente = PReserva.conseguirReserva(idReserva);
        if (reservaExistente == null) {
            System.out.println("Reserva no encontrada.");
            return;
        }

        System.out.print("Ingrese nuevo ID del huésped (actual: " + reservaExistente.getHuesped().getIdHuesped() + "): ");
        int idHuesped = Integer.parseInt(escaner.nextLine());

        System.out.print("Ingrese nuevo ID del hotel (actual: " + reservaExistente.getHotel().getIdHotel() + "): ");
        int idHotel = Integer.parseInt(escaner.nextLine());

        System.out.print("Ingrese nuevo ID de la habitación (actual: " + reservaExistente.getHabitacion().getIdHabitacion() + "): ");
        int idHabitacion = Integer.parseInt(escaner.nextLine());

        System.out.print("Ingrese nueva cantidad de personas (actual: " + reservaExistente.getCantidadPersonas() + "): ");
        int cantidadPersonas = Integer.parseInt(escaner.nextLine());

        System.out.print("Ingrese nueva fecha de inicio (actual: " + reservaExistente.getFechaInicio() + "): ");
        LocalDate fechaInicio = LocalDate.parse(escaner.nextLine());

        System.out.print("Ingrese nueva fecha de fin (actual: " + reservaExistente.getFechaFin() + "): ");
        LocalDate fechaFin = LocalDate.parse(escaner.nextLine());

        System.out.print("¿Está abonado completamente? (actual: " + reservaExistente.isAbonadoCompletamente() + "): ");
        boolean abonadoCompletamente = Boolean.parseBoolean(escaner.nextLine());

        System.out.print("Ingrese nuevas observaciones (actual: " + reservaExistente.getObservacion() + "): ");
        String observacion = escaner.nextLine();

        reservaExistente.setHuesped(new Huesped(idHuesped, "", "", "", "", "", LocalDate.now(), "", ""));
        reservaExistente.setHotel(new Hotel(idHotel, "", "", "", 0, "", "", null));
        reservaExistente.setHabitacion(new Habitacion(idHabitacion, null, 0, false, false, false, false, false, false));
        reservaExistente.setCantidadPersonas(cantidadPersonas);
        reservaExistente.setFechaInicio(fechaInicio);
        reservaExistente.setFechaFin(fechaFin);
        reservaExistente.setAbonadoCompletamente(abonadoCompletamente);
        reservaExistente.setObservacion(observacion);

        if (PReserva.modificarReserva(reservaExistente)) {
            System.out.println("Reserva modificada con éxito.");
        } else {
            System.out.println("Hubo un error al modificar la reserva.");
        }
    }

    public void conseguirReserva() {
        System.out.print("Ingrese Id de la reserva: ");
        int idReserva = Integer.parseInt(escaner.nextLine());

        Reserva reserva = PReserva.conseguirReserva(idReserva);
        if (reserva != null) {
            System.out.println(reserva);
        } else {
            System.out.println("Reserva no encontrada.");
        }
    }

    public void listarReservas() {
        ArrayList<Reserva> reservas = PReserva.listarReservas();
        if (reservas.isEmpty()) {
            System.out.println("No hay reservas registradas.");
        } else {
            for (Reserva reserva : reservas) {
                System.out.println(reserva);
            }
        }
    }
}
