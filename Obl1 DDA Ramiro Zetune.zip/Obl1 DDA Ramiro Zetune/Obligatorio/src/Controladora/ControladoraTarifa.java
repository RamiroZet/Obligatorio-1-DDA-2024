package Controladora;

import Dominio.Habitacion;
import Dominio.Reserva;
import Dominio.Tarifa;
import Persistencia.PReserva;
import Persistencia.PTarifa;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class ControladoraTarifa {
    private static Scanner escaner = new Scanner(System.in);

    public void agregarTarifa() {
        System.out.println("Agregar tarifa");

        System.out.print("Ingrese ID de la habitación: ");
        int idHabitacion = Integer.parseInt(escaner.nextLine());

        System.out.print("Ingrese fecha de inicio (YYYY-MM-DD): ");
        LocalDate fechaInicio = LocalDate.parse(escaner.nextLine());

        System.out.print("Ingrese precio por noche: ");
        double precioNoche = Double.parseDouble(escaner.nextLine());

        Tarifa tarifa = new Tarifa(new Habitacion(idHabitacion, null, 0, false, false, false, false, false, false), fechaInicio, precioNoche);

        if (PTarifa.agregarTarifa(tarifa)) {
            System.out.println("Tarifa agregada con éxito.");
        } else {
            System.out.println("Hubo un error al agregar la tarifa.");
        }
    }

    public void eliminarTarifa() {
        System.out.print("Ingrese ID de la tarifa a eliminar: ");
        int idTarifa = Integer.parseInt(escaner.nextLine());

        if (PTarifa.eliminarTarifa(idTarifa)) {
            System.out.println("Tarifa eliminada con éxito.");
        } else {
            System.out.println("No se pudo eliminar la tarifa. Verifique el ID.");
        }
    }

    public void modificarTarifa() {
        System.out.print("Ingrese ID de la tarifa a modificar: ");
        int idTarifa = Integer.parseInt(escaner.nextLine());

        Tarifa tarifaExistente = PTarifa.conseguirTarifa(idTarifa);
        if (tarifaExistente == null) {
            System.out.println("Tarifa no encontrada.");
            return;
        }

        System.out.print("Ingrese nuevo ID de la habitación (actual: " + tarifaExistente.getHabitacion().getIdHabitacion() + "): ");
        int idHabitacion = Integer.parseInt(escaner.nextLine());

        System.out.print("Ingrese nueva fecha de inicio (actual: " + tarifaExistente.getFechaInicio() + "): ");
        LocalDate fechaInicio = LocalDate.parse(escaner.nextLine());

        System.out.print("Ingrese nuevo precio por noche (actual: " + tarifaExistente.getPrecioNoche() + "): ");
        double precioNoche = Double.parseDouble(escaner.nextLine());

        tarifaExistente.setHabitacion(new Habitacion(idHabitacion, null, 0, false, false, false, false, false, false));
        tarifaExistente.setFechaInicio(fechaInicio);
        tarifaExistente.setPrecioNoche(precioNoche);

        if (PTarifa.modificarTarifa(tarifaExistente)) {
            System.out.println("Tarifa modificada con éxito.");
        } else {
            System.out.println("Hubo un error al modificar la tarifa.");
        }
    }

    public void conseguirTarifa() {
        System.out.print("Ingrese Id de la tarifa: ");
        int idTarifa = Integer.parseInt(escaner.nextLine());

        Tarifa tarifa = PTarifa.conseguirTarifa(idTarifa);
        if (tarifa != null) {
            System.out.println(tarifa);
        } else {
            System.out.println("Tarifa no encontrada.");
        }
    }

    public void listarTarifas() {
        ArrayList<Tarifa> tarifas = PTarifa.listarTarifas();
        if (tarifas.isEmpty()) {
            System.out.println("No hay tarifas registradas.");
        } else {
            for (Tarifa tarifa : tarifas) {
                System.out.println(tarifa);
            }
        }
    }
}

