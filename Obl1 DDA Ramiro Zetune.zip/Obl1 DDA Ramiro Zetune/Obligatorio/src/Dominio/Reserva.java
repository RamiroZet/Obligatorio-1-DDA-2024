package Dominio;

import java.time.LocalDate;

public class Reserva {
    private int IdReserva;
    private Huesped Huesped;
    private Hotel Hotel;
    private Habitacion Habitacion;
    private int CantidadPersonas;
    private LocalDate FechaInicio;
    private LocalDate FechaFin;
    private boolean AbonadoCompletamente; // Si se pagó completamente
    private LocalDate FechaReserva;
    private String Observacion;

    public int getIdReserva() {
        return IdReserva;
    }

    public Huesped getHuesped() {
        return Huesped;
    }
    public Hotel getHotel() {
        return Hotel;
    }
    public Habitacion getHabitacion() {
        return Habitacion;
    }

    public int getCantidadPersonas() {
        return CantidadPersonas;
    }

    public LocalDate getFechaInicio() {
        return FechaInicio;
    }

    public LocalDate getFechaFin() {
        return FechaFin;
    }

    public boolean isAbonadoCompletamente() {
        return AbonadoCompletamente;
    }

    public LocalDate getFechaReserva() {
        return FechaReserva;
    }

    public String getObservacion() {
        return Observacion;
    }

    public void setIdReserva(int idReserva) {
        this.IdReserva = idReserva;
    }

    public void setHuesped(Huesped huesped) {
        this.Huesped = huesped;
    }
    public void setHotel(Hotel hotel) {
        this.Hotel = hotel;
    }
    public void setHabitacion(Habitacion habitacion) {
        this.Habitacion = habitacion;
    }

    public void setCantidadPersonas(int cantidadPersonas) {
        this.CantidadPersonas = cantidadPersonas;
    }

    public void setFechaInicio(LocalDate fechaInicio) {
        this.FechaInicio = fechaInicio;
    }

    public void setFechaFin(LocalDate fechaFin) {
        this.FechaFin = fechaFin;
    }

    public void setAbonadoCompletamente(boolean abonadoCompletamente) {
        this.AbonadoCompletamente = abonadoCompletamente;
    }

    public void setFechaReserva(LocalDate fechaReserva) {
        this.FechaReserva = fechaReserva;
    }

    public void setObservacion(String observacion) {
        this.Observacion = observacion;
    }

    @Override
    public String toString() {
        return "Dominio.Reserva{" +
                "IdReserva=" + IdReserva +
                ", Huesped=" + Huesped +
                ", Hotel=" + Hotel +
                ", Habitacion=" + Habitacion +
                ", CantidadPersonas='" + CantidadPersonas +
                ", FechaInicio=" + FechaInicio +
                ", FechaFin=" + FechaFin +
                ", AbonadoCompletamente=" + AbonadoCompletamente +
                ", FechaReserva=" + FechaReserva +
                ", Observacion='" + Observacion + '\'' +
                '}';
    }

    /* Constructor */
    public Reserva(int pIdReserva, Huesped pHuesped, Hotel pHotel, Habitacion pHabitacion,  int pCantidadPersonas, LocalDate pFechaInicio, LocalDate pFechaFin, boolean pAbonadoCompletamente, LocalDate pFechaReserva, String pObservacion) {
        this.IdReserva = pIdReserva;
        this.Huesped = pHuesped;
        this.Hotel = pHotel;
        this.Habitacion = pHabitacion;
        this.CantidadPersonas = pCantidadPersonas;
        this.FechaInicio = pFechaInicio;
        this.FechaFin = pFechaFin;
        this.AbonadoCompletamente = pAbonadoCompletamente;
        this.FechaReserva = pFechaReserva;
        this.Observacion = pObservacion;
    }
    /* Constructor */
    public Reserva(Huesped pHuesped, Hotel pHotel, Habitacion pHabitacion,  int pCantidadPersonas, LocalDate pFechaInicio, LocalDate pFechaFin, boolean pAbonadoCompletamente, LocalDate pFechaReserva, String pObservacion) {
        this.Huesped = pHuesped;
        this.Hotel = pHotel;
        this.Habitacion = pHabitacion;
        this.CantidadPersonas = pCantidadPersonas;
        this.FechaInicio = pFechaInicio;
        this.FechaFin = pFechaFin;
        this.AbonadoCompletamente = pAbonadoCompletamente;
        this.FechaReserva = pFechaReserva;
        this.Observacion = pObservacion;
    }
}
