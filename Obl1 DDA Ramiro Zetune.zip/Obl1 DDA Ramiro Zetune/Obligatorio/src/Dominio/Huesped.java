package Dominio;

import java.time.LocalDate;

public class Huesped {
    private int IdHuesped;
    private String Nombre;
    private String Apaterno;
    private String Amaterno;
    private String Tipo_Documento;
    private String Num_Documento;
    private LocalDate Fecha_Nac;
    private String Telefono;
    private String Pais;

    /*Getters*/
    public int getIdHuesped() {
        return IdHuesped;
    }
    public String getNombre() {
        return Nombre;
    }
    public String getApaterno() {
        return Apaterno;
    }
    public String getAmaterno() {
        return Amaterno;
    }
    public String getTipo_Documento() {
        return Tipo_Documento;
    }
    public String getNum_Documento() {
        return Num_Documento;
    }
    public LocalDate getFecha_Nac() {
        return Fecha_Nac;
    }
    public String getTelefono() {
        return Telefono;
    }
    public String getPais() {
        return Pais;
    }

    /*Setters*/
    public void setIdHuesped(int idHuesped) {
        IdHuesped = idHuesped;
    }
    public void setNombre(String nombre) {
        Nombre = nombre;
    }
    public void setApaterno(String apaterno) {
        Apaterno = apaterno;
    }
    public void setAmaterno(String amaterno) {
        Amaterno = amaterno;
    }
    public void setTipo_Documento(String tipo_Documento) {
        Tipo_Documento = tipo_Documento;
    }
    public void setNum_Documento(String num_Documento) {
        Num_Documento = num_Documento;
    }
    public void setFecha_Nac(LocalDate fecha_Nac) {
        Fecha_Nac = fecha_Nac;
    }
    public void setTelefono(String telefono) {
        Telefono = telefono;
    }
    public void setPais(String pais) {
        Pais = pais;
    }

    @Override
    public String toString() {
        return "Dominio.Huesped{" +
                "IdHuesped=" + IdHuesped +
                ", Nombre='" + Nombre + '\'' +
                ", Tipo_Documento='" + Tipo_Documento + '\'' +
                ", Num_Documento='" + Num_Documento + '\'' +
                ", Fecha_Nac=" + Fecha_Nac +
                ", Telefono='" + Telefono + '\'' +
                ", Pais='" + Pais + '\'' +
                '}';
    }

    public Huesped(int pIdHuesped, String pNombre, String pApaterno, String pAmaterno, String pTipo_Documento, String pNum_Documento, LocalDate pFecha_Nac, String pTelefono, String pPais){
        this.IdHuesped = pIdHuesped;
        this.Nombre = pNombre;
        this.Apaterno = pApaterno;
        this.Amaterno = pAmaterno;
        this.Tipo_Documento = pTipo_Documento;
        this.Num_Documento = pNum_Documento;
        this.Fecha_Nac = pFecha_Nac;
        this.Telefono = pTelefono;
        this.Pais = pPais;
    }
}