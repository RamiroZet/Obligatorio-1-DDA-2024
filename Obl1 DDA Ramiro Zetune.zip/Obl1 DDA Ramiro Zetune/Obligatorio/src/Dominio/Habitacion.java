package Dominio;

public class Habitacion {
    private int IdHabitacion;
    private Hotel Hotel; // Referencia a la instancia de Dominio.Hotel
    private int CapacidadCamas;
    private boolean CamaMatrimonial;
    private boolean AireAcondicionado;
    private boolean Balcon;
    private boolean Vista;
    private boolean Amenities;
    private boolean Ocupada;

    // Constructor
    public Habitacion(int idHabitacion, Hotel hotel, int capacidadCamas, boolean camaMatrimonial, boolean aireAcondicionado, boolean balcon, boolean vista, boolean amenities, boolean ocupada) {
        this.IdHabitacion = idHabitacion;
        this.Hotel = hotel;
        this.CapacidadCamas = capacidadCamas;
        this.CamaMatrimonial = camaMatrimonial;
        this.AireAcondicionado = aireAcondicionado;
        this.Balcon = balcon;
        this.Vista = vista;
        this.Amenities = amenities;
        this.Ocupada = ocupada;
    }

    // Getters y Setters

    public int getIdHabitacion() {
        return IdHabitacion;
    }

    public void setIdHabitacion(int idHabitacion) {
        IdHabitacion = idHabitacion;
    }

    public Dominio.Hotel getHotel() {
        return Hotel;
    }

    public void setHotel(Dominio.Hotel hotel) {
        Hotel = hotel;
    }

    public int getCapacidadCamas() {
        return CapacidadCamas;
    }

    public void setCapacidadCamas(int capacidadCamas) {
        CapacidadCamas = capacidadCamas;
    }

    public boolean isCamaMatrimonial() {
        return CamaMatrimonial;
    }

    public void setCamaMatrimonial(boolean camaMatrimonial) {
        CamaMatrimonial = camaMatrimonial;
    }

    public boolean isAireAcondicionado() {
        return AireAcondicionado;
    }

    public void setAireAcondicionado(boolean aireAcondicionado) {
        AireAcondicionado = aireAcondicionado;
    }

    public boolean isBalcon() {
        return Balcon;
    }

    public void setBalcon(boolean balcon) {
        Balcon = balcon;
    }

    public boolean isVista() {
        return Vista;
    }

    public void setVista(boolean vista) {
        Vista = vista;
    }

    public boolean isAmenities() {
        return Amenities;
    }

    public void setAmenities(boolean amenities) {
        Amenities = amenities;
    }

    public boolean isOcupada() {
        return Ocupada;
    }

    public void setOcupada(boolean ocupada) {
        Ocupada = ocupada;
    }

    @Override
    public String toString() {
        return "Habitacion{" +
                "IdHabitacion=" + IdHabitacion +
                ", Hotel=" + (Hotel != null ? Hotel.toString() : "No asignado") +
                ", CapacidadCamas=" + CapacidadCamas +
                ", CamaMatrimonial=" + CamaMatrimonial +
                ", AireAcondicionado=" + AireAcondicionado +
                ", Balcon=" + Balcon +
                ", Vista=" + Vista +
                ", Amenities=" + Amenities +
                ", Ocupada=" + Ocupada +
                '}';
    }
}
