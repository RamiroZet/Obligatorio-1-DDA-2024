package Dominio;

import java.time.LocalDate;

public class Tarifa {
    private int idTarifa; // Añadir el atributo idTarifa
    private Habitacion habitacion;
    private LocalDate fechaInicio;
    private double precioNoche;

    public int getIdTarifa() {return idTarifa;}

    public void setIdTarifa(int idTarifa) {this.idTarifa = idTarifa;}

    public Habitacion getHabitacion() {return habitacion;}

    public void setHabitacion(Habitacion habitacion) {this.habitacion = habitacion;}

    public LocalDate getFechaInicio() {return fechaInicio;}

    public void setFechaInicio(LocalDate fechaInicio) {this.fechaInicio = fechaInicio;}

    public double getPrecioNoche() {return precioNoche;}

    public void setPrecioNoche(double precioNoche) {this.precioNoche = precioNoche;}

    @Override
    public String toString() {
        return "Dominio.Reserva{" +
                "IdTarifa=" + idTarifa +
                ", Habitacion=" + habitacion +
                ", FechaInicio=" + fechaInicio +
                ", PrecioNoche=" + precioNoche + '\'' +
                '}';
    }

    // Constructor con idTarifa
    public Tarifa(int idTarifa, Habitacion habitacion, LocalDate fechaInicio, double precioNoche) {
        this.idTarifa = idTarifa;
        this.habitacion = habitacion;
        this.fechaInicio = fechaInicio;
        this.precioNoche = this.precioNoche;
    }

    // Constructor sin idTarifa, para crear nuevas tarifas
    public Tarifa(Habitacion habitacion, LocalDate fechaInicio, double precioPorNoche) {
        this.habitacion = habitacion;
        this.fechaInicio = fechaInicio;
        this.precioNoche = precioPorNoche;
    }
}